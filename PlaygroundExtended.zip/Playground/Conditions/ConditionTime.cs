using UnityEngine;
using UnityEngine.UI;

[AddComponentMenu("ConditionTime")]
public class ConditionTime : ConditionBase
{
    public Text TimerObject;

    public bool Countdown = false;
    public float CountdownSeconds = 3f;
    public Time TimeRemaining;
    public string TimeOverMessage;
    private bool TimeReached = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        TimerObject.text = ""; 
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        if (Countdown )
        {
            if (!TimeReached)
            {
                // Countdown timer with limit
                CountdownSeconds -= Time.deltaTime;

                float minutes = Mathf.FloorToInt(CountdownSeconds / 60);
                float seconds = Mathf.FloorToInt(CountdownSeconds % 60);

                TimerObject.text = string.Format("{0:00}:{1:00}", minutes, seconds);

                // Add Stop Timer State
                if (CountdownSeconds <= 1)
                {
                    TimeReached = true;
                    if (TimeOverMessage != "")
                    {
                        TimerObject.text = TimeOverMessage;
                    } else
                    {
                        TimerObject.text = "00:00";
                    }
                        ExecuteAllActions(null);
                }
            }
        }
        else
        {
            // Regular Count up Timer with no limit
            System.TimeSpan timeSpan = System.TimeSpan.FromSeconds(Time.time); 
            TimerObject.text = timeSpan.ToString("mm\\:ss"); // Formats as "02:05"

        }
    }
}
