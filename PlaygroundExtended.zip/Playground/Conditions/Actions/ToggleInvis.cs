using UnityEngine;

[AddComponentMenu("Playground/Actions/Toggle Invisibility")]
public class ToggleInvis : Action
{
    // Which Camera to Control
    public string TagForInvisibles;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // Find all GameObjects tagged "Enemy"
        GameObject[] invisObjects = GameObject.FindGameObjectsWithTag(TagForInvisibles);

        if (invisObjects.Length > 0)
        {
            Debug.Log("Finding " + TagForInvisibles + " on start");
            foreach (GameObject invis in invisObjects)
            {
               
                Debug.Log("Found " + TagForInvisibles + " GameObject: " + invis.name);

            }
        }
        else
        {
            Debug.LogWarning("No GameObjects with tag " + TagForInvisibles + " found.");
        }
    }

    public override bool ExecuteAction(GameObject dataObject)
    {
        GameObject[] invisObjects = GameObject.FindGameObjectsWithTag(TagForInvisibles);

        if (invisObjects.Length > 0)
        {
            foreach (GameObject invis in invisObjects)
            {
                // Object can still be interacted with (From On-Off Script)
                // Leaving this code here to allow invisible interactable objects?
                SpriteRenderer sr = invis.GetComponent<SpriteRenderer>();
                if (sr != null)
                {
                    sr.enabled = !sr.enabled;
                }
                else
                {
                    //at least object doesn't have a Sprite Renderer component so the action can't be performed!
                    Debug.LogWarning("At least one " + TagForInvisibles + " does not have a SpriteRenderer.");
                }   
                // This would change the object to completely inactive, but can't bring it back!
                //if (invis.activeSelf)
                //{
                //    invis.SetActive(false);
                //} 
                //else
                //{
                //    if (!invis.activeSelf)
                //    {
                //        invis.SetActive(true);
                //    }
                //}
                
               
            }
        }
        else
        {
            Debug.LogWarning("No GameObjects with tag " + TagForInvisibles + " found.");
            return false;
        }

        return true;
    }
}
