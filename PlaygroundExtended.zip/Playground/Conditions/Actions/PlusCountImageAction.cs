﻿using System.Collections;
using UnityEngine;

[AddComponentMenu("Playground/Actions/PlusCountImage")]
public class PlusCountImage : Action
{
	public CountSystemAttribute objectToAffect;


	public override bool ExecuteAction(GameObject dataObject)
	{
		if(objectToAffect != null)
		{
            objectToAffect.PlusCount();

            return true;
		}
		else
		{
			Debug.Log("No object to affect");
			return false;
		}
	}
}
