using UnityEngine;

[AddComponentMenu("Playground/Actions/Camera Zoom")]
public class cameraZoom : Action
{
    // V1: Basica Functionality / Immediate Size Change
    // V2: Lerped Transition
    // Future Option: Return to original size
    // Future Option: Focus on new target & return to old target

    // Which Camera to Control
    public Camera zoomCamera;
    public bool AnimateChange = true;
    public float Duration = 2f;
    public float NewSize = 5f;
    private float OriginalSize;
    private float TimeElapsed;
    private bool AnimateNow = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    public override bool ExecuteAction(GameObject dataObject)
    {

        if (zoomCamera != null)
        {
            // Reset Time
            TimeElapsed = 0;
            // Set original size first
            OriginalSize = zoomCamera.orthographicSize;
            if (AnimateChange)
            {
                // Animate the camera using Fixed Update
                AnimateNow = true;
            } else {
            //Sudden change
            zoomCamera.orthographicSize = NewSize;
            }
        }
        else
        {
            Debug.LogError("No Camera assigned to CameraZoom script.");
        }
        TimeElapsed = 0;
        return true;
    }

    public void FixedUpdate()
    {
        if(AnimateChange && AnimateNow)
        {
            if(TimeElapsed < Duration)
            {
                // calc time
                float t = TimeElapsed / Duration;

                // repeat lerp
                zoomCamera.orthographicSize = Mathf.Lerp(OriginalSize, NewSize, t);

                // Increment the elapsed time
                TimeElapsed += Time.deltaTime;
            } else
            {
                // Animation is done, stop using Fixed Update
                AnimateNow = false;
            }
        }
    }

}
