using UnityEngine;

[AddComponentMenu("Playground/Actions/Change Speed")]

public class ChangeSpeedAction : Action
{

    // Which Camera to Control
    public Move speedObject;
    public float NewSpeed = 5f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }


    public override bool ExecuteAction(GameObject dataObject)
    {
        if (speedObject != null)
        {
            speedObject.speed = NewSpeed;
        }
        else
        {
            Debug.LogError("No Object assigned to Change Speed script.");
        }

        return true;
    }
}
