using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using static UnityEngine.GraphicsBuffer;

[AddComponentMenu("Playground/Conditions/Actions/SetVariable")]

    public class SetVariable : Action
{
    public GameObject VariableGameObject;
    public string VariableName;
    public bool TypeBool;
    public bool BoolValue;
    public bool TypeInt;
    public int IntValue;
    public bool TypeString;
    public string StringValue;

    private void Start()
    {
        
    }

    // Read the input from the player
    void Update()
	{
        
    }


    // FixedUpdate is called every frame when the physics are calculated
    void FixedUpdate()
	{
          
    }

    public override bool ExecuteAction(GameObject dataObject)
    {
        //VariableGameObject.VariableName - 
        return true;
    }
}
