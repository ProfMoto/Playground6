﻿using System.Collections;
using UnityEngine;

[AddComponentMenu("Playground/Actions/ChangeCountImage")]
public class ChangeCountImage : Action
{
	public CountSystemAttribute objectToAffect;


	public override bool ExecuteAction(GameObject dataObject)
	{
		if(objectToAffect != null)
		{
            objectToAffect.ModifyCount();

            return true;
		}
		else
		{
			Debug.Log("No object to affect");
			return false;
		}
	}
}
