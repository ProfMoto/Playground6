using UnityEngine;
using static Unity.Burst.Intrinsics.X86.Avx;

[AddComponentMenu("Playground/Conditions/Action/Fill Container Action")]
public class ContainerFillAction : Action
{
    public float emptyAlpha = 0.1f;
    public float filledAlpha = 1f;
    private SpriteRenderer thisSprite;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
        thisSprite = GetComponent<SpriteRenderer>();
        Color currentColor = thisSprite.color;
        currentColor.a = emptyAlpha;
        thisSprite.GetComponent<SpriteRenderer>().color = currentColor;

    }

    public override bool ExecuteAction(GameObject dataObject)
    {
        Color currentColor = thisSprite.color; 
        currentColor.a = filledAlpha;
        thisSprite.GetComponent<SpriteRenderer>().color = currentColor;
        return true;
    }
}
