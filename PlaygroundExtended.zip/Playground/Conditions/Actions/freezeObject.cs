using UnityEngine;
using System.Collections;

public class freezeObject : Action
{
    //public GameObject objectToFreeze; 
    //public Rigidbody rb; // Assign this in the Inspector
    public Rigidbody2D rb;

    public override bool ExecuteAction(GameObject dataObject)
    {
        if (rb != null)
        {
            //rb = objectToFreeze.GetComponent<Rigidbody2D>();

            // Freeze position on the Y-axis
            //rb.constraints = RigidbodyConstraints.FreezePositionY;

            // Freeze position on the X and Z axes
            // rb.constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ;

            // Freeze position on all axes
            rb.constraints = RigidbodyConstraints2D.FreezePosition;
        }
        return true;
    }
}
