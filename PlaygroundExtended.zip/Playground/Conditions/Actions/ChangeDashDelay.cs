using UnityEngine;

[AddComponentMenu("Playground/Actions/Change Dash Delay")]

public class ChangeDashDelayAction : Action
{

    // Which Camera to Control
    public DashUI DashObject;
    public float NewDelay = 0.1f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }


    public override bool ExecuteAction(GameObject dataObject)
    {
        if (DashObject != null)
        {
            DashObject.timeToRecharge = NewDelay;
        }
        else
        {
            Debug.LogError("No Object assigned to Change Speed script.");
        }

        return true;
    }
}
