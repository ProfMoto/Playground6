﻿using UnityEngine;
using System.Collections;

[AddComponentMenu("Playground/Gameplay/Object Shooter Action")]
public class ObjectShooterAction : Action
{
	[Header("Object creation")]
	
	public GameObject prefabToSpawn;

	// The rate of creation
	public float creationRate = .5f;

	// The speed at which the object are shot along the Y axis
	public float shootSpeed = 5f;

	public Vector2 shootDirection = new Vector2(1f, 1f);

	public bool relativeToRotation = true;

	private float timeOfLastSpawn;

	// Will be set to 0 or 1 depending on how the GameObject is tagged (or 2 for Boss Fight)
	private int playerNumber;


	// Use this for initialization
	void Start ()
	{
		timeOfLastSpawn = -creationRate;

		// Updated to consider Boss tag
        // Questionable original coding as no tag becomes owned by Player 2
        // Set the player number based on the GameObject tag
		playerNumber = (gameObject.CompareTag("Player")) ? 0 : 1;
        playerNumber = (gameObject.CompareTag("Boss")) ? 2 : 1;
	}


    public override bool ExecuteAction(GameObject dataObject)
    {
        Vector2 actualBulletDirection = (relativeToRotation) ? (Vector2)(Quaternion.Euler(0, 0, transform.eulerAngles.z) * shootDirection) : shootDirection;

        GameObject newObject = Instantiate<GameObject>(prefabToSpawn);
        newObject.transform.position = this.transform.position;
        newObject.transform.eulerAngles = new Vector3(0f, 0f, Utils.Angle(actualBulletDirection));
        newObject.tag = "Bullet";

        // push the created objects, but only if they have a Rigidbody2D
        Rigidbody2D rigidbody2D = newObject.GetComponent<Rigidbody2D>();
        if (rigidbody2D != null)
        {
            rigidbody2D.AddForce(actualBulletDirection * shootSpeed, ForceMode2D.Impulse);
        }

        // add a Bullet component if the prefab doesn't already have one, and assign the player ID
        BulletAttribute b = newObject.GetComponent<BulletAttribute>();
        if (b == null)
        {
            b = newObject.AddComponent<BulletAttribute>();
        }
        b.playerId = playerNumber;

        return true;
    }

    // Removed Gizmos for Fall 2025
    //void OnDrawGizmosSelected()
    //{
    //	if(this.enabled)
    //	{
    //		float extraAngle = (relativeToRotation) ? transform.rotation.eulerAngles.z : 0f;
    //		Utils.DrawShootArrowGizmo(transform.position, shootDirection, extraAngle, 1f);
    //	}
    //}
}
