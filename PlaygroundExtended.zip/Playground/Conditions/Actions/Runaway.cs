using System.Collections;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

[AddComponentMenu("Playground/Conditions/Actions/Runaway")]
[RequireComponent(typeof(Rigidbody2D))]

//public class Push : Physics2DObject
    public class Runaway : Action
{
	public float TimeToRun = 5f;
    public float speed = 1f; // Time it takes to return to position
    private Vector2 StartPosition;
    private FollowTarget targetScript;
    private bool RunThis = false;
    public bool UseTimer = false;
    private float TimeRemaining = 0;

    private void Start()
    {
        // On Start set the origin location to aim at for the runaway effect
        StartPosition = transform.position;
        targetScript = GetComponent<FollowTarget>();
}

    // Read the input from the player
    void Update()
	{
        
    }

    // FixedUpdate is called every frame when the physics are calculated
    void FixedUpdate()
	{
        if (RunThis)
        {
            Debug.Log("Running Away");
            //Move towards the target
            GetComponent<Rigidbody2D>().MovePosition(Vector2.Lerp(transform.position, StartPosition, Time.fixedDeltaTime * speed));

            // Add a Timer to RunThis using TimeToRun
            if (UseTimer && (TimeRemaining > 0))
            {
                TimeRemaining -= Time.deltaTime;
                if (TimeRemaining < 0)
                {
                    RunThis = false;
                    Debug.Log("Stopped Running");
                    // Restart Follow Target
                    targetScript.enabled = true;
                }
            }
        }

        
    }

    public override bool ExecuteAction(GameObject dataObject)
    {
        RunThis = true;
        // Stop Follow Target
        targetScript.enabled = false;
        TimeRemaining = TimeToRun;
        return true;
    }
}
