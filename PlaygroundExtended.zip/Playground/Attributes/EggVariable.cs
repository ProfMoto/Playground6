﻿using UnityEngine;
using System.Collections;
using System.Runtime.CompilerServices;

[AddComponentMenu("Playground/Attributes/EggVariable")]
public class EggVariable : MonoBehaviour
{
	public int egg = 0;
    public GameObject DropEgg;

    private void Start()
	{
    }

    public void PlusEgg()
	{
        egg++;
        this.transform.GetChild(0).gameObject.SetActive(true);
    }

    public void MinusEgg() {
        if (egg == 1) {
            egg--;
            // drop a new egg prefab
            this.transform.GetChild(0).gameObject.SetActive(false);
            Quaternion spawnRotation = Quaternion.identity; // No rotation
            GameObject anotherObject = Instantiate(DropEgg, this.transform.position, spawnRotation);
            Debug.Log(this.transform);
        }
    }
}
