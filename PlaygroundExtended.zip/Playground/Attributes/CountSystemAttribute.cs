﻿using UnityEngine;
using System.Collections;

[AddComponentMenu("Playground/Attributes/Count System")]
public class CountSystemAttribute : MonoBehaviour
{
	public int count = 3;
    public bool DestroyAtZero = false;
    private UIScript ui;

    private void Start()
	{
        // Find the UI in the scene and store a reference for later use
        //ui = GameObject.FindObjectOfType<UIScript>();
        ui = GameObject.FindFirstObjectByType<UIScript>();
    }

    public void IncrementCount()
	{

        this.transform.GetChild(count).gameObject.SetActive(false); 
        count++;
		Debug.Log(count);
        this.transform.GetChild(count).gameObject.SetActive(true);

        // Should there be an over max checker?

	}
    // Modify change to Subtract later?
    public void ModifyCount() { 
        this.transform.GetChild(count).gameObject.SetActive(false);
        count--;
        Debug.Log(count);
        this.transform.GetChild(count).gameObject.SetActive(true);

        //DEAD
        if (count <= 0)
        {
            // Call Game Over
            ui.GameOver(0);
            if (DestroyAtZero)
            {
                Destroy(gameObject);
            }
        }
    }

    public void PlusCount()
    {
        this.transform.GetChild(count).gameObject.SetActive(false);
        count++;
        Debug.Log(count);
        this.transform.GetChild(count).gameObject.SetActive(true);

        // Add a Max Count Feature later?
        
    }
}
