using UnityEngine;
using UnityEngine.UI;

[AddComponentMenu("Timer")]
public class Timer : MonoBehaviour
{
    public Text TimerObject;

    public bool Countdown = false;
    public float CountdownSeconds = 3f;
    public Time TimeRemaining;
    private bool TimeReached = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        TimerObject.text = ""; 
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Countdown )
        {
            if (!TimeReached)
            {

                // Countdown timer with limit
                CountdownSeconds -= Time.deltaTime;

                float minutes = Mathf.FloorToInt(CountdownSeconds / 60);
                float seconds = Mathf.FloorToInt(CountdownSeconds % 60);

                TimerObject.text = string.Format("{0:00}:{1:00}", minutes, seconds);

                // Add Stop Timer State
                if (CountdownSeconds <= 0)
                {
                    Debug.Log("Time is up");
                    TimeReached = true;
                    TimerObject.text = "Time's Up!";
                }
            }
        }
        else
        {
            // Regular Count up Timer with no limit
            System.TimeSpan timeSpan = System.TimeSpan.FromSeconds(Time.time); 
            TimerObject.text = timeSpan.ToString("mm\\:ss"); // Formats as "02:05"

        }
    }
}
