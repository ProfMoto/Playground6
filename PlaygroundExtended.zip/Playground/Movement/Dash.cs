using UnityEngine;
using System.Collections;

[AddComponentMenu("Playground/Movement/Dash")]
[RequireComponent(typeof(Rigidbody2D))]
public class Dash : Physics2DObject
{
	[Header("Input key")]

	// the key used to activate the push
	public KeyCode key = KeyCode.E;

	[Header("Direction and strength")]

	// strength of the push, and the axis on which it is applied (can be X or Y)
	public float pushStrength = 5f;
	public Enums.Axes axis = Enums.Axes.X;
	public bool relativeAxis = true;

    private bool keyPressed = false;
	private Vector2 pushVector;

    [Header("Recharge")]
    public bool useRecharge = true;
    public float timeToRecharge = 5f;

    private float startTime;
    private bool dashReady = true;

    // Read the input from the player
    void Update()
	{
        keyPressed = Input.GetKeyDown(key);
        if (keyPressed && dashReady)
        {
            pushVector = Utils.GetVectorFromAxis(axis) * pushStrength;
            startTime = Time.time;

            //Apply the push
            if (relativeAxis)
            {
                GetComponent<Rigidbody2D>().AddRelativeForce(pushVector);
            }
            else
            {
                GetComponent<Rigidbody2D>().AddForce(pushVector);
            }
            if (useRecharge == true)
            {
                dashReady = false;
            }
        }

        if (Time.time >= startTime + timeToRecharge)
        {
            dashReady = true;
        }
    }

    //Removed Gizmos for Fall 2025
	//Draw an arrow to show the direction in which the object will move
    //void OnDrawGizmosSelected()
	//{
	//	if(this.enabled)
	//	{
	//		float extraAngle = (relativeAxis) ? transform.rotation.eulerAngles.z : 0f;
	//		pushVector = Utils.GetVectorFromAxis(axis) * pushStrength;
	//		Utils.DrawMoveArrowGizmo(transform.position, pushVector, extraAngle, pushStrength * .5f);
	//	}
	//}
}
