//using System.Collections;
//using System.Diagnostics;
using UnityEngine;
using UnityEngine.UI; // Required for UI elements like Image

[AddComponentMenu("Playground/Movement/DashUIObject")]
[RequireComponent(typeof(Rigidbody2D))]
public class DashUIObject : Physics2DObject
{
    private ConsumeResourceAction consume;

    [Header("Input key")]

	// the key used to activate the push
	public KeyCode key = KeyCode.E;

	[Header("Direction and strength")]

	// strength of the push, and the axis on which it is applied (can be X or Y)
	public float pushStrength = 500f;
	public Enums.Axes axis = Enums.Axes.X;
	public bool relativeAxis = true;

    private bool keyPressed = false;
	private Vector2 pushVector;

    [Header("Recharge")]
    public bool useRechargeTime = true;
    public float timeToRecharge = 0.2f;
    [Header("Add Consume Resource for Recharge Object")] 
    public bool useRechargeObject = false;
    
    

    private float startTime;
    private bool dashReady = true;
    private bool dashCharge = true;

    [Header("Dash UI")]
    public Image fillBarImage; // Assign your UI Image component in the Inspector
    // use timeToRecharge = maxValue instead of setting in Editor
    // public float maxValue = 100f; // Maximum value for the bar (e.g., max health)
    private float maxValue;
    private float currentValue; // Current value of the bar (e.g., current health)

    private void Start()
    {
        // Set path to Consume Action on this gameobject
        consume = GetComponent<ConsumeResourceAction>();

        // Use maxValue set to Time To Recharge rather than setting this in Editor
        maxValue = timeToRecharge;
        // Initialize current value to max value at the start
        currentValue = maxValue;
        fillBarImage.enabled = false; 
        UpdateFillBar();
    }

    // Function to update the fill bar based on a new value
    public void SetValue(float newValue)
    {
        currentValue = Mathf.Clamp(newValue, 0, maxValue); // Clamp value between 0 and maxValue
        UpdateFillBar();
    }

    // Function to change the fill bar by a certain amount
    public void ChangeValue(float amount)
    {
        currentValue += amount;
        currentValue = Mathf.Clamp(currentValue, 0, maxValue);
        UpdateFillBar();
    }

    // Updates the fill amount of the Image component
    private void UpdateFillBar()
    {
        if (fillBarImage != null)
        {
            fillBarImage.fillAmount = currentValue / maxValue;
            //Debug.Log(currentValue / maxValue);
        }
    }

    // Read the input from the player
    void Update()
	{
        keyPressed = Input.GetKeyDown(key);
        
        if (keyPressed)
        {
            // Check if dash needs to recharge with an item, consume it if it does
            if (!dashCharge)
            {
                if (consume.ExecuteAction(this.gameObject))
                {
                    dashCharge = true;
                }

            }
            if (dashReady)
            {
                if (dashCharge)
                {
                    pushVector = Utils.GetVectorFromAxis(axis) * pushStrength;
                    startTime = Time.time;

                    //Apply the push
                    if (relativeAxis)
                    {
                        GetComponent<Rigidbody2D>().AddRelativeForce(pushVector);
                    }
                    else
                    {
                        GetComponent<Rigidbody2D>().AddForce(pushVector);
                    }

                    if (useRechargeTime == true)
                    {
                        fillBarImage.enabled = true;
                        dashReady = false;
                        SetValue(0);
                    }

                    if (useRechargeObject == true)
                    {
                        dashCharge = false;
                    }
                } 
                else
                {
                    Debug.Log("No charge ready for dash");
                    
                }
            }
        }

        // Recharge the meter if dash cooldown and using recharge time
        if (dashReady == false && useRechargeTime == true)
        {
            if (Time.time >= startTime + timeToRecharge)
            {
                //Debug.Log("ready");
                fillBarImage.enabled = false; 
                dashReady = true;
            }
            else
            { 
                currentValue = Time.time - startTime;
                SetValue(currentValue);
               
            }
        }
    }

    //Removed Gizmos for Fall 2025
	//Draw an arrow to show the direction in which the object will move
    //void OnDrawGizmosSelected()
	//{
	//	if(this.enabled)
	//	{
	//		float extraAngle = (relativeAxis) ? transform.rotation.eulerAngles.z : 0f;
	//		pushVector = Utils.GetVectorFromAxis(axis) * pushStrength;
	//		Utils.DrawMoveArrowGizmo(transform.position, pushVector, extraAngle, pushStrength * .5f);
	//	}
	//}
}
