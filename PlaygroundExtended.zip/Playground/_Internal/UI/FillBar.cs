using UnityEngine;
using UnityEngine.UI; // Required for UI elements like Image

public class FillBarController : MonoBehaviour
{
    public Image fillBarImage; // Assign your UI Image component in the Inspector
    public float maxValue = 100f; // Maximum value for the bar (e.g., max health)
    private float currentValue; // Current value of the bar (e.g., current health)

    void Start()
    {
        // Initialize current value to max value at the start
        currentValue = maxValue;
        UpdateFillBar();
    }

    // Function to update the fill bar based on a new value
    public void SetValue(float newValue)
    {
        currentValue = Mathf.Clamp(newValue, 0, maxValue); // Clamp value between 0 and maxValue
        UpdateFillBar();
    }

    // Function to change the fill bar by a certain amount
    public void ChangeValue(float amount)
    {
        currentValue += amount;
        currentValue = Mathf.Clamp(currentValue, 0, maxValue);
        UpdateFillBar();
    }

    // Updates the fill amount of the Image component
    private void UpdateFillBar()
    {
        if (fillBarImage != null)
        {
            fillBarImage.fillAmount = currentValue / maxValue;
        }
    }
}